document.addEventListener('DOMContentLoaded', () => {

    let currentUser = null;
    let usersList = [];
    let bookingsList = [];
    let requestsList = [];
    
    // API KONFIGURATION
    const API_URL = '/zes/api/v1'; 

    async function apiFetch(endpoint, method = 'GET', body = null, isFormData = false) {
        const headers = {};
        if (currentUser && currentUser.token) headers['Authorization'] = `Bearer ${currentUser.token}`;
        if (!isFormData) headers['Content-Type'] = 'application/json';
        const config = { method, headers };
        if (body) config.body = isFormData ? body : JSON.stringify(body);
        try {
            const res = await fetch(`${API_URL}${endpoint}`, config);
            if (!res.ok) { 
                if(res.status===401) logout(); 
                return null; 
            }
            return await res.json();
        } catch (err) { console.error(err); return null; }
    }

    // LOGIN LOGIK
    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const u = document.getElementById('username').value;
        const p = document.getElementById('password').value;
        const data = await apiFetch('/login', 'POST', { username: u, password: p });
        
        if (data && data.status === "success") {
            currentUser = { ...data.user, token: data.token };
            document.getElementById('user-display-name').textContent = currentUser.displayName;
            document.getElementById('client-name-display').textContent = currentUser.clientName || "System"; 
            
            // UI Setup nach Rolle
            if (currentUser.role === 'admin') {
                document.getElementById('nav-dashboard-button').classList.add('hidden');
                document.getElementById('nav-live-button').classList.remove('hidden');
                document.getElementById('user-live-terminal').classList.add('hidden');
                document.getElementById('admin-live-dashboard').classList.remove('hidden');
                usersList = await apiFetch('/users');
                switchSection('live');
            } else {
                document.getElementById('nav-dashboard-button').classList.remove('hidden');
                document.getElementById('nav-live-button').classList.add('hidden');
                document.getElementById('user-live-terminal').classList.remove('hidden');
                document.getElementById('admin-live-dashboard').classList.add('hidden');
                usersList = [{ 
                    id: currentUser.id, 
                    displayName: currentUser.displayName, 
                    dailyTarget: currentUser.dailyTarget, 
                    vacationDays: currentUser.vacationDays 
                }];
                switchSection('dashboard');
            }
            
            initAllDropdowns();
            checkNotifications(); 

            document.getElementById('login-page').classList.add('hidden');
            document.getElementById('tracker-page').classList.remove('hidden');
        } else {
            document.getElementById('error-message').classList.remove('hidden');
        }
    });

    document.getElementById('logout-button').addEventListener('click', () => logout());
    function logout() { currentUser = null; location.reload(); }

    // --- MOBILE MENU ---
    const mobileMenu = document.getElementById('mobile-menu-overlay');
    document.getElementById('mobile-menu-btn').addEventListener('click', () => {
        mobileMenu.classList.remove('hidden');
        const liveBtn = document.getElementById('mob-nav-live');
        if(liveBtn) {
            if(currentUser && currentUser.role === 'admin') liveBtn.classList.remove('hidden');
            else liveBtn.classList.add('hidden');
        }
    });
    
    document.getElementById('close-mobile-menu').addEventListener('click', () => mobileMenu.classList.add('hidden'));
    
    const mobNavMap = { 
        'dashboard': 'dashboard',
        'mob-nav-live': 'live', 
        'mob-nav-journal': 'overview', 
        'mob-nav-requests': 'requests', 
        'mob-nav-calendar': 'monthly', 
        'mob-nav-account': 'account', 
        'mob-nav-history': 'history' 
    };
    Object.keys(mobNavMap).forEach(id => {
        const btn = document.getElementById(id);
        if(btn) btn.addEventListener('click', () => {
            switchSection(mobNavMap[id]);
            mobileMenu.classList.add('hidden');
        });
    });
    document.getElementById('mob-logout').addEventListener('click', () => logout());

    // --- DROPDOWNS INITIALISIEREN ---
    function initAllDropdowns() {
        const selects = ['overview-user-select', 'req-filter-user', 'request-target-user', 'cal-filter-user', 'account-user-select'];
        selects.forEach(id => {
            const el = document.getElementById(id);
            if(!el) return;
            el.innerHTML = '<option value="" disabled selected>Bitte wählen...</option>';
            usersList.filter(u => u.role !== 'admin').forEach(u => {
                el.add(new Option(u.displayName, u.id));
            });
        });

        const monthSelect = document.getElementById('cal-filter-month');
        if(monthSelect) {
            monthSelect.innerHTML = '';
            ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'].forEach((m, i) => {
                monthSelect.add(new Option(m, i));
            });
            monthSelect.value = new Date().getMonth();
        }

        const yearSelect = document.getElementById('cal-filter-year');
        if(yearSelect) {
            yearSelect.innerHTML = '';
            [2024, 2025, 2026, 2027].forEach(y => yearSelect.add(new Option(y, y)));
            yearSelect.value = new Date().getFullYear();
        }

        // Standard Zeitraum: Monatserster bis Heute
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        const startInp = document.getElementById('filter-date-start');
        const endInp = document.getElementById('filter-date-end');
        if(startInp) startInp.value = firstDay.toISOString().split('T')[0];
        if(endInp) endInp.value = today.toISOString().split('T')[0];
    }

    // --- NAVIGATION ---
    function switchSection(name) {
        document.querySelectorAll('.content-section').forEach(el => el.classList.add('hidden'));
        const contentEl = document.getElementById(`content-${name}`);
        if(contentEl) contentEl.classList.remove('hidden');
        refreshData(name);
    }
    window.switchSection = switchSection;
    
    const navMap = { 'dashboard': 'dashboard','overview':'overview', 'live':'live', 'requests':'requests', 'monthly':'monthly', 'account':'account', 'history':'history' };
    Object.keys(navMap).forEach(k => {
        const btn = document.getElementById(`nav-${k}-button`);
        if(btn) btn.addEventListener('click', () => switchSection(navMap[k]));
    });

    async function refreshData(name) {
        bookingsList = await apiFetch('/bookings') || [];
        requestsList = await apiFetch('/requests') || [];
        if (name === 'overview') loadOverview();
        if (name === 'live') loadLiveMonitor();
        if (name === 'requests') loadRequests();
        if (name === 'monthly') loadMonthly();
        if (name === 'history') loadHistory();
        if (name === 'account') loadTimeAccount();
        if (name === 'dashboard') loadDashboard();
    }

    // HELPER FUNKTIONEN
    function getUserName(id) { const u = usersList.find(u => u.id === id); return u ? u.displayName : `Pers.-Nr. ${id}`; }
    function timeToDec(t) { if(!t) return 0; const [h,m] = t.split(':').map(Number); return h + m/60; }
    function decToTime(d) { const h = Math.floor(Math.abs(d)); const m = Math.round((Math.abs(d)-h)*60); return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`; }
    function calcPause(brutto) { return brutto > 9 ? 0.75 : (brutto > 6 ? 0.5 : 0); }
    function getUserTarget(uid) { const u = usersList.find(x=>x.id===uid); return u ? (u.dailyTarget||8.0) : 8.0; }

    // Enddatum Input Toggle
    window.toggleEndDateInput = function() {
        const type = document.getElementById('req-type-select').value;
        const endContainer = document.getElementById('container-end-date');
        const startLabel = document.getElementById('label-date-start');
        
        if (type === 'Urlaub' || type === 'Krank') {
            endContainer.classList.remove('hidden');
            startLabel.innerText = "Von";
        } else {
            endContainer.classList.add('hidden');
            startLabel.innerText = "Datum";
            const endInput = document.querySelector('input[name="endDate"]');
            if(endInput) endInput.value = '';
        }
    };

    // --- FUNKTIONEN ---

    // 1. ECHTZEIT MONITOR / STEMPELN
    window.manualStamp = async (action) => {
        const res = await apiFetch('/stamp-manual', 'POST', { action });
        if(res && res.status === 'success') { refreshData('live'); }
    };
    
    function loadLiveMonitor() {
        const today = new Date().toLocaleDateString('en-CA'); 
        
        if(currentUser.role !== 'admin') {
            const myLast = bookingsList.filter(b => b.userId === currentUser.id && b.date === today).pop();
            const statEl = document.getElementById('status-display');
            const lastStamp = document.getElementById('last-stamp-time');

            if(myLast && !myLast.end) {
                statEl.textContent = "ANWESEND"; 
                statEl.className = "text-5xl lg:text-6xl font-brand font-bold text-green-400 mb-4 drop-shadow-md";
                lastStamp.textContent = `Seit ${myLast.start} Uhr`;
                lastStamp.className = "inline-block bg-[#0a192f] px-6 py-2 rounded-full text-green-400 font-mono border border-green-900/50 mb-10 text-sm";
            } else {
                statEl.textContent = "ABWESEND"; 
                statEl.className = "text-5xl lg:text-6xl font-brand font-bold text-gray-500 mb-4 drop-shadow-md";
                lastStamp.textContent = "--:--";
                lastStamp.className = "inline-block bg-[#0a192f] px-6 py-2 rounded-full text-gray-500 font-mono border border-[#233554] mb-10 text-sm";
            }
            return;
        }

        const container = document.getElementById('live-users-grid');
        container.innerHTML = '';
        
        const active = bookingsList.filter(b => b.date === today && b.start && !b.end);
        
        if (active.length === 0) { 
            container.innerHTML = '<div class="col-span-full text-center text-gray-500 italic p-10">Aktuell sind keine Mitarbeiter aktiv.</div>'; 
            return; 
        }

        active.forEach(b => {
            container.innerHTML += `
                <div class="bg-[#112240] border-l-4 border-green-500 p-4 rounded shadow-lg flex items-center justify-between animate-fade hover:bg-[#1a2f55] transition">
                    <div>
                        <div class="font-bold text-white text-lg font-brand">${getUserName(b.userId)}</div>
                        <div class="text-green-400 font-mono text-sm mt-1">
                            <i class="fas fa-clock mr-1"></i> Seit ${b.start} Uhr
                        </div>
                    </div>
                    <div class="relative">
                        <div class="h-3 w-3 bg-green-500 rounded-full"></div>
                        <div class="absolute top-0 left-0 h-3 w-3 bg-green-500 rounded-full animate-ping opacity-75"></div>
                    </div>
                </div>`;
        });
    }

    // 2. JOURNAL (Übersicht)
    async function loadOverview() {
        const isAdmin = currentUser.role === 'admin';
        const filterUser = document.getElementById('overview-user-select');
        const startInp = document.getElementById('filter-date-start');
        const endInp = document.getElementById('filter-date-end');
        
        if(isAdmin) document.getElementById('admin-filters-overview').classList.remove('hidden');
        document.getElementById('apply-filter-btn').onclick = loadOverview;

        let url = '/bookings?';
        if(startInp && endInp && startInp.value && endInp.value) {
            url += `from=${startInp.value}&to=${endInp.value}&`;
        }
        
        let data = await apiFetch(url); 
        if(!data) data = [];

        if (isAdmin && filterUser.value) data = data.filter(b => b.userId == filterUser.value);
        else if (!isAdmin) data = data.filter(b => b.userId === currentUser.id);

        data.sort((a,b) => new Date(b.date) - new Date(a.date));

        const container = document.getElementById('overview-list-container');
        const header = document.getElementById('overview-header');
        container.innerHTML = '';

        // Grid Definition
        const gridClass = isAdmin ? 
            'grid-cols-[0.5fr_1.5fr_1fr_0.7fr_0.7fr_0.6fr_0.6fr_0.6fr_0.8fr_2fr_0.5fr]' : 
            'grid-cols-[1fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr_2fr]';
        
        let headHTML = isAdmin ? `<div class="text-textMuted">ID</div><div class="text-textMuted">Name</div>` : ``;
        headHTML += `
            <div class="text-textMuted">Datum</div>
            <div class="text-center text-textMuted">Beginn</div>
            <div class="text-center text-textMuted">Ende</div>
            <div class="text-center text-textMuted text-[10px] uppercase">Pause</div>
            <div class="text-center text-textMuted text-[10px] uppercase">Soll</div>
            <div class="text-center text-textMuted text-[10px] uppercase">Ist</div>
            <div class="text-center font-bold text-brand">Netto</div>
            ${isAdmin ? '' : '<div class="text-center text-textMuted">Saldo</div>'} 
            <div class="text-textMuted">Info</div>`;
        if(isAdmin) headHTML += `<div class="text-center text-white"><i class="fas fa-cog"></i></div>`;
        
        header.className = `grid ${gridClass} gap-2 px-4 py-3 bg-[#0d1b33] border-b border-border text-xs font-bold uppercase items-center sticky top-0 z-10`;
        header.innerHTML = headHTML;

        if(data.length === 0) { container.innerHTML = '<div class="p-10 text-center text-gray-500 italic">Keine Einträge für diesen Zeitraum.</div>'; return; }

        data.forEach(b => {
            const target = getUserTarget(b.userId);
            const rawDiff = timeToDec(b.end) - timeToDec(b.start);
            const pause = b.end ? calcPause(rawDiff) : 0;
            const net = Math.max(0, rawDiff - pause);
            const saldo = b.end ? (net - target) : 0;
            
            let typeBadge = '';
            if (b.type === 'Urlaub') typeBadge = '<span class="text-[9px] bg-blue-900/50 text-blue-300 px-1 rounded mr-1 border border-blue-800">URLAUB</span>';
            if (b.type === 'Krank') typeBadge = '<span class="text-[9px] bg-red-900/50 text-red-300 px-1 rounded mr-1 border border-red-800">KRANK</span>';

            const div = document.createElement('div');
            div.className = `grid ${gridClass} gap-2 px-4 py-3 items-center hover:bg-[#1a2f55] transition border-b border-border text-sm text-gray-300 group`;
            
            let html = isAdmin ? `<div class="font-mono text-xs text-gray-500">${b.userId}</div><div class="font-bold text-white truncate text-xs">${getUserName(b.userId)}</div>` : ``;
            
            html += `<div class="text-gray-400 font-mono text-xs">${b.date.split('-').reverse().join('.')}</div>
                <div class="text-center font-mono bg-[#0a192f] rounded py-0.5 text-xs">${b.start}</div>
                <div class="text-center font-mono bg-[#0a192f] rounded py-0.5 text-xs">${b.end || '--:--'}</div>
                <div class="text-center text-gray-500 text-xs font-mono">${decToTime(pause)}</div>
                <div class="text-center text-gray-500 text-xs font-mono">${decToTime(target)}</div>
                <div class="text-center text-gray-500 text-xs font-mono">${b.end ? decToTime(rawDiff) : '-'}</div>
                <div class="text-center font-bold text-brand font-mono text-sm">${b.end ? decToTime(net) : '...'}</div>
                ${isAdmin ? '' : `<div class="text-center font-mono font-bold ${saldo >= 0 ? 'text-green-500' : 'text-red-500'}">${b.end ? (saldo>0?'+':'')+decToTime(saldo) : '-'}</div>`}
                <div class="truncate text-gray-400 text-xs">${typeBadge}${b.remarks||''}</div>`;
            
            if(isAdmin) html += `<div class="text-center"><button onclick="window.openEdit(${b.id})" class="text-brand hover:text-white transition"><i class="fas fa-pen text-xs"></i></button></div>`;
            
            div.innerHTML = html;
            container.appendChild(div);
        });
    }

    // 3. ANTRÄGE
    window.handleRequest = async (id, status) => {
        if(!confirm(`Status wirklich ändern?`)) return;
        const res = await apiFetch(`/requests/${id}`, 'PUT', { status });
        if(res && res.status === 'success') refreshData('requests');
    };

    function loadRequests() {
        const isAdmin = currentUser.role === 'admin';
        const listContainer = document.getElementById('request-list-container');
        
        if (isAdmin) {
            document.getElementById('admin-request-filter-area').classList.remove('hidden');
            document.getElementById('admin-request-filter-area').classList.add('flex');
            document.getElementById('request-target-user-container').classList.remove('hidden');
            document.getElementById('req-filter-btn').onclick = loadRequests;
        }

        let data = requestsList;
        if (isAdmin) {
            const fUserId = document.getElementById('req-filter-user').value;
            const fStatus = document.getElementById('req-filter-status').value;
            if(fUserId) data = data.filter(r => r.userId == fUserId);
            if(fStatus) data = data.filter(r => r.status === fStatus);
        }
        data.sort((a,b) => b.id - a.id);

        listContainer.innerHTML = '';
        if(data.length === 0) { listContainer.innerHTML = '<p class="text-gray-500 italic p-4 text-center">Keine Anträge vorhanden.</p>'; return; }

        data.forEach(req => {
            const item = document.createElement('div');
            item.className = "bg-[#0a192f] p-4 rounded border border-border mb-3 hover:border-brand/50 transition shadow-sm relative overflow-hidden";
            
            let dateDisplay = req.date;
            if(req.endDate) dateDisplay += ` <i class="fas fa-arrow-right text-[10px] mx-1"></i> ${req.endDate}`;

            let statusBadge = '';
            if(req.status === 'pending') statusBadge = '<span class="text-yellow-500 bg-yellow-900/20 px-2 py-0.5 rounded text-[10px] font-bold border border-yellow-900/50">OFFEN</span>';
            else if(req.status === 'approved') statusBadge = '<span class="text-green-500 bg-green-900/20 px-2 py-0.5 rounded text-[10px] font-bold border border-green-900/50">GENEHMIGT</span>';
            else statusBadge = '<span class="text-red-500 bg-red-900/20 px-2 py-0.5 rounded text-[10px] font-bold border border-red-900/50">ABGELEHNT</span>';

            let buttons = (isAdmin && req.status === 'pending') ? 
                `<div class="mt-3 flex gap-2 justify-end border-t border-border pt-2">
                    <button onclick="window.handleRequest(${req.id}, 'approved')" class="text-xs bg-green-600 hover:bg-green-500 text-white px-3 py-1 rounded font-bold shadow">OK</button>
                    <button onclick="window.handleRequest(${req.id}, 'rejected')" class="text-xs bg-red-600 hover:bg-red-500 text-white px-3 py-1 rounded font-bold shadow">ABLEHNEN</button>
                </div>` : '';
            
            item.innerHTML = `
                <div class="flex justify-between items-start mb-2">
                    <div class="flex items-center gap-2">
                         <div class="text-sm font-bold text-white font-brand">${getUserName(req.userId)}</div>
                    </div>
                    ${statusBadge}
                </div>
                <div class="text-xs text-brand font-bold mb-1 uppercase tracking-wide">${req.type} <span class="text-gray-500 font-normal ml-2 font-mono">${dateDisplay}</span></div>
                <div class="bg-[#112240] p-2 rounded text-xs text-gray-300 italic mb-1 border border-border/50">"${req.reason}"</div>
                ${buttons}`;
            listContainer.appendChild(item);
        });
    }

    document.getElementById('request-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
            targetUserId: e.target.targetUserId ? e.target.targetUserId.value : null,
            type: e.target.type.value,
            date: e.target.date.value,
            endDate: e.target.endDate.value,
            newStart: e.target.newStart.value,
            newEnd: e.target.newEnd.value,
            reason: e.target.reason.value
        };
        
        if(data.endDate && data.endDate < data.date) {
            alert("Das Enddatum darf nicht vor dem Startdatum liegen.");
            return;
        }

        const res = await apiFetch('/requests', 'POST', data, false); 
        if (res && res.status === 'success') { 
            alert('Antrag erfolgreich übermittelt.'); 
            e.target.reset(); 
            window.toggleEndDateInput();
            refreshData('requests'); 
        }
    });

    // 4. KALENDER
    window.loadMonthly = function() {
        const grid = document.getElementById('calendar-grid');
        const calUserContainer = document.getElementById('cal-user-container');
        const calFilterUser = document.getElementById('cal-filter-user');
        
        const selectedMonth = parseInt(document.getElementById('cal-filter-month').value);
        const selectedYear = parseInt(document.getElementById('cal-filter-year').value);
        
        let targetUserId = currentUser.id;
        
        if (currentUser.role === 'admin') {
            calUserContainer.classList.remove('hidden');
            if (calFilterUser.value) {
                targetUserId = parseInt(calFilterUser.value);
            } else {
                grid.innerHTML = '<div class="col-span-7 text-center py-10 text-gray-500">Bitte Mitarbeiter wählen & Laden klicken.</div>';
                return;
            }
        } else {
            calUserContainer.classList.add('hidden');
        }

        grid.innerHTML = '';
        const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
        let firstDayIndex = new Date(selectedYear, selectedMonth, 1).getDay(); firstDayIndex = firstDayIndex === 0 ? 6 : firstDayIndex - 1; 

        ['Mo','Di','Mi','Do','Fr','Sa','So'].forEach(d => {
             const h = document.createElement('div'); h.className = `text-center text-[10px] font-bold text-gray-500 py-2 uppercase tracking-wider bg-[#0d1b33]`; h.innerText = d;
             grid.appendChild(h);
        });
        for (let i = 0; i < firstDayIndex; i++) grid.appendChild(document.createElement('div'));

        let sumTarget = 0, sumActual = 0;
        const target = getUserTarget(targetUserId);

        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const cell = document.createElement('div');
            const isWeekend = (new Date(selectedYear, selectedMonth, day).getDay() % 6 === 0);
            
            cell.className = `min-h-[90px] p-2 border-t border-l border-border relative flex flex-col transition ${isWeekend ? 'bg-[#050f1e]' : 'bg-[#112240] hover:bg-[#1a2f55]'}`;
            cell.innerHTML = `<div class="text-right text-xs font-bold ${isWeekend ? 'text-brand' : 'text-gray-500'} mb-1">${day}</div>`;

            const b = bookingsList.find(x => x.date === dateStr && x.userId === targetUserId);
            if (b) {
                const diff = timeToDec(b.end) - timeToDec(b.start);
                const pause = b.end ? calcPause(diff) : 0;
                const net = Math.max(0, diff - pause);
                if (!isWeekend) sumTarget += target;
                sumActual += net;
                
                let colorClass = 'text-green-400 bg-green-900/10 border-green-900/30';
                let label = b.end ? decToTime(net)+'h' : 'Läuft...';
                
                if(b.type === 'Krank') { label = 'KRANK'; colorClass = 'text-red-400 bg-red-900/10 border-red-900/30'; }
                if(b.type === 'Urlaub') { label = 'URLAUB'; colorClass = 'text-blue-300 bg-blue-900/10 border-blue-900/30'; }

                cell.innerHTML += `<div class="mt-auto text-[10px] text-center font-bold border rounded py-1 px-1 ${colorClass}">${label}</div>`;
                if(currentUser.role === 'admin') { 
                    cell.onclick = () => window.openEdit(b.id); 
                    cell.classList.add('cursor-pointer'); 
                }
            } else if(!isWeekend && dateStr < new Date().toISOString().split('T')[0]) {
                 sumTarget += target;
                 cell.innerHTML += `<div class="mt-auto text-center text-[9px] text-red-800 font-bold uppercase tracking-wider">Fehlt</div>`;
            }
            grid.appendChild(cell);
        }
        document.getElementById('cal-stat-target').textContent = decToTime(sumTarget);
        document.getElementById('cal-stat-actual').textContent = decToTime(sumActual);
        const bal = sumActual - sumTarget;
        document.getElementById('cal-stat-balance').textContent = (bal>0?'+':'') + decToTime(bal);
        document.getElementById('cal-stat-balance').className = `text-xl font-mono font-bold ${bal>=0?'text-green-400':'text-red-400'}`;
    };

    window.exportToCSV = function() {
        const selectedMonth = parseInt(document.getElementById('cal-filter-month').value) + 1;
        const selectedYear = document.getElementById('cal-filter-year').value;
        const prefix = `${selectedYear}-${String(selectedMonth).padStart(2,'0')}`;
        
        let targetUserId = currentUser.id;
        if(currentUser.role === 'admin') {
            const val = document.getElementById('cal-filter-user').value;
            if(!val) { alert("Bitte Mitarbeiter für Export wählen."); return; }
            targetUserId = val;
        }

        let csvContent = "data:text/csv;charset=utf-8,\uFEFFPers.-Nr.;Name;Datum;Start;Ende;Pause;Soll;Ist;Netto;Saldo;Bemerkung\n";
        let data = bookingsList.filter(b => b.date.startsWith(prefix) && b.userId == targetUserId);
        
        if(data.length === 0) { alert("Keine Daten für diesen Zeitraum vorhanden."); return; }
        data.sort((a,b) => new Date(a.date) - new Date(b.date));

        data.forEach(b => {
            const target = getUserTarget(b.userId);
            const brutto = timeToDec(b.end) - timeToDec(b.start);
            const pause = b.end ? calcPause(brutto) : 0;
            const erfasst = Math.max(0, brutto - pause);
            const saldo = b.end ? (erfasst - target) : 0;
            csvContent += [b.userId, getUserName(b.userId), b.date, b.start, b.end||'', decToTime(pause), decToTime(target), decToTime(brutto), decToTime(erfasst), decToTime(saldo), b.remarks||''].join(";") + "\n";
        });
        const link = document.createElement("a");
        link.href = encodeURI(csvContent);
        link.download = `Export_${prefix}_${targetUserId}.csv`;
        link.click();
    };

    // 5. ZEITKONTO
    function loadTimeAccount() {
        const isAdmin = currentUser.role === 'admin';
        const filterArea = document.getElementById('account-filter-area');
        const userSelect = document.getElementById('account-user-select');

        if (isAdmin) {
            filterArea.classList.remove('hidden');
            filterArea.classList.add('flex');
            if(!userSelect.value) { return; }
        } else {
            filterArea.classList.add('hidden');
        }

        const targetId = isAdmin ? parseInt(userSelect.value) : currentUser.id;
        const user = usersList.find(u => u.id === targetId) || currentUser;
        const bookings = bookingsList.filter(b => b.userId === targetId);
        
        let totalBalance = 0;
        let vacationTaken = 0;
        let sickDays = 0;
        const currentYear = new Date().getFullYear();

        bookings.forEach(b => {
            if(b.end && b.type !== 'Krank' && b.type !== 'Urlaub') {
                const diff = timeToDec(b.end) - timeToDec(b.start);
                const pause = calcPause(diff);
                const net = Math.max(0, diff - pause);
                const dateObj = new Date(b.date);
                const isWeekend = dateObj.getDay() === 0 || dateObj.getDay() === 6;
                const effectiveTarget = isWeekend ? 0 : (user.dailyTarget || 8.0);
                totalBalance += (net - effectiveTarget);
            }
            if(new Date(b.date).getFullYear() === currentYear) {
                if(b.type === 'Urlaub') vacationTaken++;
                if(b.type === 'Krank') sickDays++;
            }
        });

        document.getElementById('acc-balance').textContent = (totalBalance >= 0 ? '+' : '') + decToTime(Math.abs(totalBalance)) + ' h';
        document.getElementById('acc-balance').className = `text-3xl font-mono font-bold ${totalBalance >= 0 ? 'text-green-400' : 'text-red-400'}`;
        document.getElementById('acc-vacation-total').textContent = user.vacationDays || 30;
        document.getElementById('acc-vacation-left').textContent = (user.vacationDays || 30) - vacationTaken;
        document.getElementById('acc-sick').textContent = sickDays;

        const listContainer = document.getElementById('account-history-list');
        listContainer.innerHTML = '';
        const historyData = [...bookings].sort((a,b) => new Date(b.date) - new Date(a.date)).slice(0, 50);
        historyData.forEach(b => {
             const diff = b.end ? (timeToDec(b.end) - timeToDec(b.start)) : 0;
             const pause = b.end ? calcPause(diff) : 0;
             const net = Math.max(0, diff - pause);
             const div = document.createElement('div');
             div.className = "px-4 py-2 flex justify-between items-center hover:bg-[#1a2f55] text-sm text-gray-400 border-b border-border last:border-0 transition";
             div.innerHTML = `<div><span class="font-bold text-white font-mono">${b.date}</span> <span class="text-xs ml-2 text-brand">${b.type}</span></div><div class="font-mono text-white">${decToTime(net)} h</div>`;
             listContainer.appendChild(div);
        });
    }

    // 6. HISTORY LOG
     function loadHistory() {
        apiFetch('/history').then(log => {
            const tbody = document.getElementById('audit-log-body');
            tbody.innerHTML = '';
            
            if (!log || log.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="p-8 text-center text-gray-500 italic">Keine Aktivitäten aufgezeichnet.</td></tr>';
                return;
            }

            log.forEach(entry => {
                const tr = document.createElement('tr');
                tr.className = "hover:bg-[#1a2f55] border-b border-border transition text-xs";
                
                const dateStr = new Date(entry.timestamp).toLocaleString('de-DE', {day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit'});

                let whoDisplay = entry.actor;
                if (entry.affectedUser && entry.affectedUser !== entry.actor) {
                    whoDisplay += ` <i class="fas fa-arrow-right text-gray-500 mx-1"></i> <span class="text-white">${entry.affectedUser}</span>`;
                }

                tr.innerHTML = `
                    <td class="px-6 py-3 text-gray-500 font-mono whitespace-nowrap">${dateStr}</td>
                    <td class="px-6 py-3 font-bold text-gray-300">${whoDisplay}</td> 
                    <td class="px-6 py-3 font-bold text-brand uppercase tracking-wider">${entry.action}</td>
                    <td class="px-6 py-3 text-red-300 font-mono break-all">${entry.oldValue || '-'}</td>
                    <td class="px-6 py-3 text-green-300 font-mono break-all">${entry.newValue || '-'}</td>
                `;
                tbody.appendChild(tr);
            });
        });
    }

    // 7. DASHBOARD LOGIC
    async function loadDashboard() {
        const data = await apiFetch('/dashboard');
        if (!data) return;

        // Stats
        document.getElementById('dash-hours-week').textContent = data.hoursWeek.toString().replace('.', ',');
        document.getElementById('dash-next-vacation').textContent = data.nextVacation;

        // Alerts
        const alertContainer = document.getElementById('dashboard-alerts-container');
        alertContainer.innerHTML = '';
        
        if (data.alerts.length > 0) {
            alertContainer.classList.remove('hidden');
            data.alerts.forEach(alert => {
                const div = document.createElement('div');
                div.className = "bg-red-900/10 border-l-4 border-red-500 p-4 rounded flex justify-between items-center shadow-lg";
                div.innerHTML = `
                    <div>
                        <div class="text-red-400 font-bold text-sm uppercase tracking-wide"> <i class="fas fa-exclamation-triangle mr-2"></i> Buchungsfehler: ${alert.date}</div>
                        <div class="text-gray-500 text-xs mt-1">Eingestempelt um ${alert.start} Uhr - kein Ende.</div>
                    </div>
                    <button onclick="window.openCorrection('${alert.date}', '${alert.start}', ${alert.id})" class="bg-red-600 hover:bg-red-500 text-white text-xs px-4 py-2 rounded font-bold uppercase transition shadow">
                        Korrigieren
                    </button>
                `;
                alertContainer.appendChild(div);
            });
        } else {
            alertContainer.classList.add('hidden');
        }
    }

    window.openCorrection = function(date, start, id) {
        switchSection('requests');
        const parts = date.split('.');
        const isoDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
        
        const form = document.getElementById('request-form');
        if(form) {
            form.querySelector('[name="type"]').value = 'Korrektur';
            window.toggleEndDateInput(); 
            form.querySelector('[name="date"]').value = isoDate;
            form.querySelector('[name="newStart"]').value = start;
            form.querySelector('[name="reason"]').value = "Fehlende Ausstempelung";
            form.querySelector('[name="newEnd"]').focus();
        }
    };

    // EDIT MODAL
    window.openEdit = function(id) {
        const b = bookingsList.find(x => x.id === id); if(!b) return;
        document.getElementById('edit-id').value = b.id;
        document.getElementById('edit-user').value = getUserName(b.userId);
        document.getElementById('edit-start').value = b.start;
        document.getElementById('edit-end').value = b.end;
        document.getElementById('edit-remark').value = b.remarks || '';
        document.getElementById('admin-edit-modal').classList.remove('hidden');
    };
    
    document.getElementById('close-modal-btn').onclick = () => document.getElementById('admin-edit-modal').classList.add('hidden');
    
    document.getElementById('admin-edit-form').onsubmit = async (e) => {
        e.preventDefault();
        const id = document.getElementById('edit-id').value;
        const body = { 
            start: document.getElementById('edit-start').value, 
            end: document.getElementById('edit-end').value, 
            remarks: document.getElementById('edit-remark').value 
        };
        const res = await apiFetch(`/bookings/${id}`, 'PUT', body);
        
        if(res && res.status === 'success') { 
            document.getElementById('admin-edit-modal').classList.add('hidden'); 
            refreshData('overview'); 
            refreshData('monthly'); 
        } else {
            alert(res.message || "Fehler beim Speichern");
        }
    };

    // --- PASSWORT ÄNDERN ---
    const pwModal = document.getElementById('password-modal');
    const pwBtn = document.getElementById('nav-password-button');
    const pwClose = document.getElementById('close-pw-modal');
    const pwError = document.getElementById('pw-error');

    if (pwBtn) {
        pwBtn.addEventListener('click', () => {
            document.getElementById('password-form').reset();
            pwError.classList.add('hidden');
            pwModal.classList.remove('hidden');
        });
    }

    if (pwClose) {
        pwClose.addEventListener('click', () => {
            pwModal.classList.add('hidden');
        });
    }

    const pwForm = document.getElementById('password-form');
    if (pwForm) {
        pwForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const oldPw = document.getElementById('pw-old').value;
            const newPw = document.getElementById('pw-new').value;
            const confirmPw = document.getElementById('pw-confirm').value;

            if (newPw !== confirmPw) {
                pwError.textContent = "Passwörter stimmen nicht überein.";
                pwError.classList.remove('hidden');
                return;
            }

            const res = await apiFetch('/password', 'PUT', { 
                oldPassword: oldPw, 
                newPassword: newPw 
            });

            if (res && res.status === 'success') {
                alert("Passwort erfolgreich geändert!");
                pwModal.classList.add('hidden');
            } else {
                pwError.textContent = res ? res.message : "Fehler beim Speichern.";
                pwError.classList.remove('hidden');
            }
        });
    }

    // --- BENACHRICHTIGUNGEN ---
    const notifBtn = document.getElementById('notification-btn');
    const notifBadge = document.getElementById('notification-badge');
    const notifDropdown = document.getElementById('notification-dropdown');
    const notifList = document.getElementById('notification-list');
    let notifData = null; 

    setInterval(checkNotifications, 30000);
    checkNotifications(); 

    async function checkNotifications() {
        if (!currentUser) return;
        const data = await apiFetch('/notifications');
        if (!data) return;
        
        notifData = data; 

        if (data.count > 0) {
            notifBadge.textContent = data.count;
            notifBadge.classList.remove('hidden');
            notifBtn.classList.add('text-white');
            notifBtn.classList.remove('text-textMuted');
        } else {
            notifBadge.classList.add('hidden');
            notifBtn.classList.remove('text-white');
            notifBtn.classList.add('text-textMuted');
        }
    }

    if (notifBtn) {
        notifBtn.addEventListener('click', (e) => {
            e.stopPropagation(); 
            if (!notifData || notifData.count === 0) return;
            notifDropdown.classList.toggle('hidden');
            renderNotifications();
        });
    }

    function renderNotifications() {
        notifList.innerHTML = '';
        if (!notifData || !notifData.items) return;

        notifData.items.forEach(item => {
            const div = document.createElement('div');
            div.className = "p-3 border-l-4 mb-1 cursor-pointer hover:bg-[#1a2f55] transition text-xs border-b border-border last:border-0";
            
            div.onclick = () => {
                switchSection('requests');
                notifDropdown.classList.add('hidden');
                if(currentUser.role === 'admin') {
                    document.getElementById('req-filter-status').value = 'pending';
                    refreshData('requests');
                }
            };

            if (currentUser.role === 'admin') {
                div.classList.add('border-yellow-500');
                div.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div class="font-bold text-white">${item.user}</div>
                        <div class="text-[9px] text-gray-500">${item.date}</div>
                    </div>
                    <div class="text-brand font-bold mt-1">Antrag: ${item.type}</div>
                `;
            } else {
                const isOk = item.status === 'approved';
                const colorClass = isOk ? 'border-green-500' : 'border-red-500';
                const statusText = isOk ? 'Genehmigt' : 'Abgelehnt';
                const statusColor = isOk ? 'text-green-400' : 'text-red-400';

                div.classList.add(colorClass);
                div.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div class="font-bold ${statusColor}">${statusText}</div>
                        <div class="text-[9px] text-gray-500">${item.date}</div>
                    </div>
                    <div class="text-white mt-1 font-bold">${item.type}</div>
                    <div class="text-gray-400 italic truncate mt-1">"${item.reason}"</div>
                `;
            }
            notifList.appendChild(div);
        });
    }

    document.getElementById('notification-clear-btn').addEventListener('click', async (e) => {
        e.stopPropagation(); 
        if(currentUser.role !== 'admin') {
            await apiFetch('/notifications/read', 'POST', {});
        }
        notifDropdown.classList.add('hidden');
        checkNotifications(); 
    });

    window.addEventListener('click', (e) => {
        if (!notifBtn.contains(e.target) && !notifDropdown.contains(e.target)) {
            notifDropdown.classList.add('hidden');
        }
    });
});